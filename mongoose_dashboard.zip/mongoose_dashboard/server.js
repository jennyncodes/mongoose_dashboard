var express = require('express');
var session = require('express-session');
var mongoose= require('mongoose');
var bodyParser= require('body-parser');
var path = require('path');
const flash = require('express-flash');

var app= express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(flash());
app.use(session({
    secret: 'pankoandtofu',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
  }))
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost/basic_mongoose');

var DogSchema = new mongoose.Schema({
    name: {type: String, required:true},
    age: {type: Number, required: true},
})
mongoose.model('Dog', DogSchema);
var Dog = mongoose.model('Dog');
mongoose.Promise= global.Promise;

//display all of the dogs
app.get('/', function(req, res){
    Dog.find({}, function(err, dogs){
        if(err){
            console.log(err);
        }
        else{
            res.render('index', {dogs:dogs});
        }
    });
})
//display one dog information
app.get("/dogs/:id", function(req, res){
	Dog.findById(req.params.id, function(err, dog){
		if(err){
			console.log(err);
		}
		else{
			res.render("dog", {dog:dog});
		}
	})
})

//display a form for making a new dog.
app.get("/new/", function(req, res){
	res.render("new");
})

//action of creating a new dog
app.post("/dogs/new", function(req, res){
	var dog = new Dog({name: req.body.name, age: req.body.age});
	dog.save(function(err){
		if(err){
			res.render("new", {errors: dog.errors});
		}
		else{
			res.redirect("/");
		}
	})
})

//show a form to edit an existing dog
app.get("/dogs/edit/:id", function(req, res){
	Dog.findById(req.params.id, function(err, dog){
		if(err){
			console.log(err);
		}
		else{
			res.render("edit", {dog:dog});
		}
	})
})
//action for editing a dog
app.post("/dogs/:id", function(req, res){
	Dog.findById(req.params.id, function(err, dog){
		if(err){
			console.log(err);
		}
		else{
			Dog.update({_id: dog._id}, {$set: {name: req.body.name, age: req.body.age}}, {upsert: true}, function(err){
				if(err){
					console.log(err);
				}
				else{
					res.redirect("/");
				}
			})
		}
	})
})

//delete a dog
app.post("/dogs/delete/:id", function(req, res){
	Dog.findById(req.params.id, function(err, dog){
		if(err){
			console.log(err);
			res.render("edit", {dog: dog, errors: dog.errors})
		}
		else{
			Dog.remove({_id: dog._id}, function(err){
				if(err){
					console.log(err);
					console.log("Error on delete");
				}
				else{
					res.redirect("/");
				}
			});

		}
	})
})

app.listen(8000, function() {
    console.log("listening on port 8000");
})

